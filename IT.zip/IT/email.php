<?php
	$to = "sompharshi123@gmail.com";
	$subject = "My subject";
	$txt = "Hello world!";
	if(mail($to,$subject,$txt))
	{
		echo "email sent";
	}
	else
	{	
		echo "Error while sending email ";
	}
?> 
