<?php
session_start();
$_SESSION["logged_id"]=0;
$link = mysqli_connect("localhost", "root", "setmaxix", "IT") or die("Connection Error");
$sid=$_POST['sid'];
$password=$_POST['psw'];
$query="select psw from login where sid = '$sid'";
$res=mysqli_query($link,$query) or die("ERROR");
$r=mysqli_fetch_array($res);
if($r[0]==$password){
session_start();
$_SESSION["sid"]=$sid;
$_SESSION["logged_id"]=1;
if($sid=="admin")
{
header("location:admin.php");
}
else{
header("location:user.php");
}
}
elseif($r[0]==NULL)
{
die("invalid user");
}
else
{
die ("invalid password");
}
?>
