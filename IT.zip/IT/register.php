<?php
$link = mysqli_connect("localhost", "root", "setmaxix", "IT") or die("Connection Error");
$sid=$_POST['sid'];
$password=$_POST['psw'];
$email=$_POST['email'];
$cpassword=$_POST['cpsw'];
if ($password==$cpassword){
$q1= "insert into register (sid,psw,email) values ('$sid','$password','$email')";
$to=$email;
$sub="Welcome mail!";
$message="Thank you for registering on Student Calendar website!
We will contact on this email address in the future.
Contact us";
$header="From: studentcal4@gmail.com";
$result=mysqli_query($link,$q1) or die('SQL QUERY');
if($result)
{
$q2= "insert into login (sid,psw) values ('$sid','$password')";
$result1=mysqli_query($link,$q2) or die('Error in SQL INNER QUERY');
mail($to,$sub,$message,$header);
echo "<script>alert('Registeration complete!');window.location.href = 'planner_home.html';</script>";
echo "<br />";
}
}
?>	

