<?php
session_start();
if (!isset($_SESSION["sid"])){
die("Sorry you can't access this page");
}
else{
$link = mysqli_connect("localhost", "root", "setmaxix", "IT") or die("Connection Error");
//Email Announcement
$q= "select * from register";
$result=mysqli_query($link,$q) or die(mysqli_error(result));
while($r=mysqli_fetch_array($result))
{
$email=$r['email'];
$sid=$r['sid'];
if($sid == "admin")
{
//no email sent
}
else
{
$sub="New Announcement Added!";
$message="A new announcement/task has been added.Please sign in to view the task";
if(mail($email,$sub,$message))
{
echo "<script>alert('mail sent');window.location.href = 'admin.php';</script>";
}
}
}
}
