<?php
	session_start();
	if (!isset($_SESSION["sid"])){
		die("Sorry you can't access this page");
	}
	else{
		//admin interface
		echo '<link rel="stylesheet" href="login.css">';
		echo '<form method=post action=submit.php>';
		echo '<br />';
		echo 'Announcement: <input type="text" placeholder="Enter the announcement" name="ta" required>';
		echo 'Deadline: <input type="text" placeholder="Enter the deadline" name="date" required>';
		echo '<button type="submit">Submit</button>';
		echo '</form>';
		echo '	<div class="container">';
		echo '    		<span class="sign">';
		echo '<a href="signout.php" style="color:white;">Signout</a>';
		echo '</span>';
		echo '<div class="footer">';
		echo ' <p>All Copyrights Reserved &copy;Group 21</p>';
		echo '	</div>';
	}
?>
