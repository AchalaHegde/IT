A Pen created at CodePen.io. You can find this one at https://codepen.io/subodhghulaxe/pen/qEXLLr.

 This code explains, how to drag an event from FullCalendar to trash or back to external list